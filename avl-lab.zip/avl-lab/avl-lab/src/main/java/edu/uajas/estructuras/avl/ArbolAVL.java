package edu.uajas.estructuras.avl;

import java.util.ArrayList;
import java.util.List;

public class ArbolAVL {

    private NodoAVL raiz;

    public ArbolAVL() {
        this.raiz = null;
    }

    // ================================================================
    //  UTILIDADES DE ALTURA Y FACTOR DE EQUILIBRIO
    // ================================================================

    private int altura(NodoAVL nodo) {
        return (nodo == null) ? -1 : nodo.altura;
    }

    private void actualizarAltura(NodoAVL nodo) {
        nodo.altura = 1 + Math.max(altura(nodo.izquierdo), altura(nodo.derecho));
    }

    public int factorEquilibrio(NodoAVL nodo) {
        return (nodo == null) ? 0 : altura(nodo.derecho) - altura(nodo.izquierdo);
    }

    // ================================================================
    //  ROTACIONES
    // ================================================================

    private NodoAVL rotarDerecha(NodoAVL y) {
        NodoAVL x  = y.izquierdo;
        NodoAVL B  = x.derecho;

        x.derecho   = y;
        y.izquierdo = B;

        actualizarAltura(y);
        actualizarAltura(x);

        return x;
    }

    private NodoAVL rotarIzquierda(NodoAVL x) {
        NodoAVL y  = x.derecho;
        NodoAVL B  = y.izquierdo;

        y.izquierdo = x;
        x.derecho   = B;

        actualizarAltura(x);
        actualizarAltura(y);

        return y;
    }

    // ================================================================
    //  REBALANCEO
    // ================================================================

    private NodoAVL rebalancear(NodoAVL nodo) {
        actualizarAltura(nodo);
        int fe = factorEquilibrio(nodo);

        if (fe < -1 && factorEquilibrio(nodo.izquierdo) <= 0) {
            return rotarDerecha(nodo);
        }
        if (fe < -1 && factorEquilibrio(nodo.izquierdo) > 0) {
            nodo.izquierdo = rotarIzquierda(nodo.izquierdo);
            return rotarDerecha(nodo);
        }
        if (fe > 1 && factorEquilibrio(nodo.derecho) >= 0) {
            return rotarIzquierda(nodo);
        }
        if (fe > 1 && factorEquilibrio(nodo.derecho) < 0) {
            nodo.derecho = rotarDerecha(nodo.derecho);
            return rotarIzquierda(nodo);
        }

        return nodo;
    }

    // ================================================================
    //  INSERCIÓN
    // ================================================================

    public void insertar(int dato) {
        raiz = insertarRec(raiz, dato);
    }

    private NodoAVL insertarRec(NodoAVL nodo, int dato) {
        if (nodo == null) return new NodoAVL(dato);

        if      (dato < nodo.dato) nodo.izquierdo = insertarRec(nodo.izquierdo, dato);
        else if (dato > nodo.dato) nodo.derecho   = insertarRec(nodo.derecho,   dato);
        else                       return nodo;

        return rebalancear(nodo);
    }

    // ================================================================
    //  BÚSQUEDA
    // ================================================================

    public boolean buscar(int dato) {
        return buscarRec(raiz, dato);
    }

    private boolean buscarRec(NodoAVL nodo, int dato) {
        if (nodo == null)       return false;
        if (dato == nodo.dato)  return true;
        if (dato  < nodo.dato)  return buscarRec(nodo.izquierdo, dato);
        return                         buscarRec(nodo.derecho,   dato);
    }

    // ================================================================
    //  ELIMINACIÓN
    // ================================================================

    public void eliminar(int dato) {
        raiz = eliminarRec(raiz, dato);
    }

    private NodoAVL eliminarRec(NodoAVL nodo, int dato) {
        if (nodo == null) return null;

        if      (dato < nodo.dato) nodo.izquierdo = eliminarRec(nodo.izquierdo, dato);
        else if (dato > nodo.dato) nodo.derecho   = eliminarRec(nodo.derecho,   dato);
        else {
            // CASO 1: Nodo hoja
            if (nodo.izquierdo == null && nodo.derecho == null) {
                return null;
            }

            // CASO 2: Un solo hijo
            if (nodo.izquierdo == null) {
                return nodo.derecho;
            } else if (nodo.derecho == null) {
                return nodo.izquierdo;
            }

            // CASO 3: Dos hijos
            NodoAVL sucesor = minimoNodo(nodo.derecho);
            nodo.dato = sucesor.dato;
            nodo.derecho = eliminarRec(nodo.derecho, sucesor.dato);
        }

        return rebalancear(nodo);
    }

    private NodoAVL minimoNodo(NodoAVL nodo) {
        while (nodo.izquierdo != null) nodo = nodo.izquierdo;
        return nodo;
    }

    // ================================================================
    //  RECORRIDOS
    // ================================================================

    public List<Integer> inorden() {
        List<Integer> lista = new ArrayList<>();
        inordenRec(raiz, lista);
        return lista;
    }
    private void inordenRec(NodoAVL n, List<Integer> l) {
        if (n == null) return;
        inordenRec(n.izquierdo, l);
        l.add(n.dato);
        inordenRec(n.derecho, l);
    }

    public List<Integer> preorden() {
        List<Integer> lista = new ArrayList<>();
        preordenRec(raiz, lista);
        return lista;
    }
    private void preordenRec(NodoAVL n, List<Integer> l) {
        if (n == null) return;
        l.add(n.dato);
        preordenRec(n.izquierdo, l);
        preordenRec(n.derecho, l);
    }

    // ================================================================
    //  VERIFICACIÓN Y ESTADÍSTICAS
    // ================================================================

    public boolean estaBalanceado() {
        return verificarAVL(raiz);
    }

    private boolean verificarAVL(NodoAVL nodo) {
        if (nodo == null) return true;
        int fe = factorEquilibrio(nodo);
        if (Math.abs(fe) > 1) return false;
        return verificarAVL(nodo.izquierdo) && verificarAVL(nodo.derecho);
    }

    public int altura()   { return altura(raiz); }

    public int tamanio()  { return tamanioRec(raiz); }
    private int tamanioRec(NodoAVL n) {
        return n == null ? 0 : 1 + tamanioRec(n.izquierdo) + tamanioRec(n.derecho);
    }

    public boolean esVacio() { return raiz == null; }

    // ================================================================
    //  VISUALIZACIÓN EN CONSOLA
    // ================================================================

    public void imprimirArbol() {
        System.out.println("\n  Árbol AVL (valor | FE=factor de equilibrio):");
        imprimirRec(raiz, "", true);
    }

    private void imprimirRec(NodoAVL nodo, String prefijo, boolean esUltimo) {
        if (nodo == null) return;
        int fe = factorEquilibrio(nodo);
        String feStr = fe == 0 ? "FE=0" : (fe > 0 ? "FE=+" + fe : "FE=" + fe);
        System.out.println(prefijo + (esUltimo ? "└── " : "├── ") + nodo.dato + " [" + feStr + "]");
        String nuevoPrefijo = prefijo + (esUltimo ? "    " : "│   ");
        imprimirRec(nodo.izquierdo, nuevoPrefijo, nodo.derecho == null);
        imprimirRec(nodo.derecho,   nuevoPrefijo, true);
    }

    // ================================================================
    //  MÉTODOS PARA EL ESTUDIANTE — COMPLETAR
    // ================================================================
    // TODO Avanzados (rotaciones, buscarRango, comparaciones de altura)
}
