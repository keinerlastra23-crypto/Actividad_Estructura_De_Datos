package edu.uajas.estructuras.avl;

/**
 * =====================================================================
 *  NodoAVL — Nodo del Árbol AVL
 * =====================================================================
 *  UAJS – Estructuras de Datos No Lineales
 *  Ing. Jaider Reyes Herazo
 *
 *  Diferencia con NodoBST: agrega el campo 'altura' que permite
 *  calcular el Factor de Equilibrio (FE = altura(der) - altura(izq))
 * =====================================================================
 */
public class NodoAVL {

    public int dato;
    public NodoAVL izquierdo;
    public NodoAVL derecho;

    /**
     * Altura del subárbol enraizado en este nodo.
     * Nodo hoja = altura 0. Árbol vacío = -1 (convenio).
     */
    public int altura;

    public NodoAVL(int dato) {
        this.dato      = dato;
        this.izquierdo = null;
        this.derecho   = null;
        this.altura    = 0; // nuevo nodo siempre es hoja
    }

    @Override
    public String toString() {
        return "[" + dato + " h=" + altura + "]";
    }
}
