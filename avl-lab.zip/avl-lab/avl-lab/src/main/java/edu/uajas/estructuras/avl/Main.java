package edu.uajas.estructuras.avl;

import java.util.Scanner;

/**
 * =====================================================================
 *  Main – Laboratorio AVL
 * =====================================================================
 *  UAJS – Estructuras de Datos No Lineales
 *  Ing. Jaider Reyes Herazo
 *
 *  Ejecutar con Maven:
 *    mvn compile exec:java -Dexec.mainClass="edu.uajas.estructuras.avl.Main"
 * =====================================================================
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc     = new Scanner(System.in);
        ArbolAVL arbol = new ArbolAVL();
        boolean activo = true;

        System.out.println("\n" + "═".repeat(60));
        System.out.println("    LABORATORIO ÁRBOL AVL – UAJS");
        System.out.println("═".repeat(60));

        while (activo) {
            System.out.println("\n  Opciones:");
            System.out.println("  1. Demo automática (inserta 10 valores y muestra rotaciones)");
            System.out.println("  2. Taller interactivo (construye tu propio AVL)");
            System.out.println("  3. Comparativa AVL vs BST degenerado");
            System.out.println("  0. Salir");
            System.out.print("\n  → ");

            switch (sc.nextLine().trim()) {
                case "1" -> demoAutomatica();
                case "2" -> tallerInteractivo(sc);
                case "3" -> comparativaAVLvsBST();
                case "0" -> activo = false;
                default  -> System.out.println("  ⚠️  Opción no válida");
            }
        }
        sc.close();
    }

    // ── Demo automática ──────────────────────────────────────────────
// ── Demo automática ──────────────────────────────────────────────
private static void demoAutomatica() {
    System.out.println("\n" + "─".repeat(60));
    System.out.println("  DEMO: Inserción con rebalanceo automático");
    System.out.println("─".repeat(60));

    ArbolAVL avl = new ArbolAVL();
    // Estos valores producen varios tipos de rotación
    int[] valores = {10, 20, 30, 40, 50, 25, 15, 5, 35, 45};

    for (int v : valores) {
        avl.insertar(v);
        System.out.printf("%n  ➕ Insertar %2d → Altura: %d | Balanceado: %s%n",
                v, avl.altura(),
                avl.estaBalanceado() ? "Si" : "No");
    }

    avl.imprimirArbol();

    System.out.println("\n   Estadísticas finales:");
    System.out.println("     Nodos        : " + avl.tamanio());
    System.out.println("     Altura real  : " + avl.altura());
    System.out.printf ("     Altura máx.  : %.0f (teórico AVL 1.44·log₂n)%n",
                       1.44 * Math.log(avl.tamanio() + 1) / Math.log(2));
    System.out.println("     INORDEN      : " + avl.inorden());
    System.out.println("     PREORDEN     : " + avl.preorden());

    // ── Bloque de pruebas de eliminación ─────────────────────────
    System.out.println("\n   Eliminación caso 1: nodo hoja (5)");
    avl.eliminar(5);
    avl.imprimirArbol();

    System.out.println("\n    Eliminación caso 2: nodo con un hijo (45)");
    avl.eliminar(45);
    avl.imprimirArbol();

    System.out.println("\n    Eliminación caso 3: nodo con dos hijos (30)");
    avl.eliminar(30);
    avl.imprimirArbol();

    System.out.println("     INORDEN tras eliminaciones: " + avl.inorden());
    System.out.println("     Balanceado: " + (avl.estaBalanceado() ? "Si" : "No"));
}


    // ── Taller interactivo ───────────────────────────────────────────
    private static void tallerInteractivo(Scanner sc) {
        System.out.println("\n" + "─".repeat(60));
        System.out.println("  TALLER: Construye tu AVL");
        System.out.println("  Comandos: +N insertar, -N eliminar, ?N buscar");
        System.out.println("            I inorden, P preorden, V visual, Q salir");
        System.out.println("─".repeat(60));

        ArbolAVL avl  = new ArbolAVL();
        boolean activo = true;

        while (activo) {
            System.out.print("\n  AVL > ");
            String cmd = sc.nextLine().trim().toUpperCase();

            try {
                if (cmd.startsWith("+")) {
                    int n = Integer.parseInt(cmd.substring(1));
                    avl.insertar(n);
                    System.out.printf("  ✅ Insertado %d | Altura: %d | Balanceado: %s%n",
                            n, avl.altura(), avl.estaBalanceado() ? "✅" : "❌");
                } else if (cmd.startsWith("-")) {
                    int n = Integer.parseInt(cmd.substring(1));
                    avl.eliminar(n);
                    System.out.printf("  🗑️  Eliminado %d | Altura: %d | Balanceado: %s%n",
                            n, avl.altura(), avl.estaBalanceado() ? "✅" : "❌");
                } else if (cmd.startsWith("?")) {
                    int n = Integer.parseInt(cmd.substring(1));
                    System.out.printf("  🔍 %d → %s%n", n,
                            avl.buscar(n) ? "ENCONTRADO ✅" : "NO EXISTE ❌");
                } else switch (cmd) {
                    case "I" -> System.out.println("  INORDEN  : " + avl.inorden());
                    case "P" -> System.out.println("  PREORDEN : " + avl.preorden());
                    case "V" -> avl.imprimirArbol();
                    case "Q" -> activo = false;
                    default  -> System.out.println("  ⚠️  Comando desconocido");
                }
            } catch (NumberFormatException e) {
                System.out.println("  ⚠️  Número inválido");
            }
        }
    }

    // ── Comparativa AVL vs BST degenerado ────────────────────────────
    private static void comparativaAVLvsBST() {
        System.out.println("\n" + "─".repeat(60));
        System.out.println("  COMPARATIVA: AVL vs BST insertando 1..10 en orden");
        System.out.println("─".repeat(60));

        // BST degenerado (inserción en orden ascendente = lista enlazada)
        edu.uajas.estructuras.ArbolBST<Integer> bst = new edu.uajas.estructuras.ArbolBST<>();
        ArbolAVL avl = new ArbolAVL();

        for (int i = 1; i <= 10; i++) {
            bst.insertar(i);
            avl.insertar(i);
        }

        System.out.println("\n  Inserción de 1, 2, 3, ..., 10 (orden ascendente):");
        System.out.println("  ┌────────────────┬──────────┬────────────────────────┐");
        System.out.println("  │  Estructura    │  Altura  │  Complejidad búsqueda  │");
        System.out.println("  ├────────────────┼──────────┼────────────────────────┤");
        System.out.printf ("  │  BST (sin AVL) │  %3d     │  O(n)  – lista enlaz.  │%n", bst.altura());
        System.out.printf ("  │  Árbol AVL     │  %3d     │  O(log n) – garantiz.  │%n", avl.altura());
        System.out.println("  └────────────────┴──────────┴────────────────────────┘");

        System.out.println("\n  AVL (balanceado automáticamente):");
        avl.imprimirArbol();

        System.out.println("\n  BST sin balanceo (árbol tipo lista — peor caso):");
        bst.imprimirArbol();
    }
}
