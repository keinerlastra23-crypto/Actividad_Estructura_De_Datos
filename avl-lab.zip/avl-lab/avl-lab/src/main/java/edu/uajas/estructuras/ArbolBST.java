package edu.uajas.estructuras;

/**
 * =====================================================================
 *  ArbolBST — Árbol Binario de Búsqueda SIN balanceo
 * =====================================================================
 *  UAJS – Estructuras de Datos No Lineales
 *  Ing. Jaider Reyes Herazo
 *
 *  Árbol BST estándar (sin rotaciones). Usado para demostrar el
 *  peor caso: insertar en orden ascendente produce un árbol
 *  degenerado (lista enlazada), con altura O(n).
 *
 *  Contrasta con ArbolAVL que garantiza altura O(log n).
 * =====================================================================
 */
public class ArbolBST<T extends Comparable<T>> {

    // ── Nodo interno ─────────────────────────────────────────────────
    private static class Nodo<T> {
        T dato;
        Nodo<T> izquierdo;
        Nodo<T> derecho;

        Nodo(T dato) {
            this.dato      = dato;
            this.izquierdo = null;
            this.derecho   = null;
        }
    }

    private Nodo<T> raiz;

    public ArbolBST() {
        this.raiz = null;
    }

    // ================================================================
    //  INSERCIÓN — O(h), sin balanceo → O(n) en el peor caso
    // ================================================================

    public void insertar(T dato) {
        raiz = insertarRec(raiz, dato);
    }

    private Nodo<T> insertarRec(Nodo<T> nodo, T dato) {
        if (nodo == null) return new Nodo<>(dato);

        int cmp = dato.compareTo(nodo.dato);
        if      (cmp < 0) nodo.izquierdo = insertarRec(nodo.izquierdo, dato);
        else if (cmp > 0) nodo.derecho   = insertarRec(nodo.derecho,   dato);
        // duplicado: se ignora

        return nodo;
    }

    // ================================================================
    //  BÚSQUEDA
    // ================================================================

    public boolean buscar(T dato) {
        return buscarRec(raiz, dato);
    }

    private boolean buscarRec(Nodo<T> nodo, T dato) {
        if (nodo == null)                  return false;
        int cmp = dato.compareTo(nodo.dato);
        if (cmp == 0)                      return true;
        if (cmp  < 0)                      return buscarRec(nodo.izquierdo, dato);
        return                                    buscarRec(nodo.derecho,   dato);
    }

    // ================================================================
    //  ALTURA — O(n)
    // ================================================================

    /** Retorna la altura del árbol. Árbol vacío = -1. */
    public int altura() {
        return alturaRec(raiz);
    }

    private int alturaRec(Nodo<T> nodo) {
        if (nodo == null) return -1;
        return 1 + Math.max(alturaRec(nodo.izquierdo), alturaRec(nodo.derecho));
    }

    // ================================================================
    //  VISUALIZACIÓN
    // ================================================================

    /** Imprime el árbol con estructura visual (igual que ArbolAVL). */
    public void imprimirArbol() {
        System.out.println("\n  Árbol BST (sin balanceo):");
        imprimirRec(raiz, "", true);
    }

    private void imprimirRec(Nodo<T> nodo, String prefijo, boolean esUltimo) {
        if (nodo == null) return;
        System.out.println(prefijo + (esUltimo ? "└── " : "├── ") + nodo.dato);
        String nuevoPrefijo = prefijo + (esUltimo ? "    " : "│   ");
        imprimirRec(nodo.izquierdo, nuevoPrefijo, nodo.derecho == null);
        imprimirRec(nodo.derecho,   nuevoPrefijo, true);
    }

    public boolean esVacio() { return raiz == null; }
}
