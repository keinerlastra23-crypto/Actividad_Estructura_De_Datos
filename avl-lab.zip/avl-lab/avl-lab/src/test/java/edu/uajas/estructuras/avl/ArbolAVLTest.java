package edu.uajas.estructuras.avl;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

/**
 * =====================================================================
 *  Tests JUnit 5 – Árbol AVL
 * =====================================================================
 *  UAJS – Estructuras de Datos No Lineales
 *
 *  INSTRUCCIONES:
 *  1. Ejecuta: mvn test
 *  2. Los tests marcados con @Disabled son los que DEBES hacer pasar.
 *     Quita el @Disabled, implementa el código en ArbolAVL.java
 *     y vuelve a ejecutar mvn test hasta que todos pasen en verde.
 * =====================================================================
 */
@DisplayName("Tests Árbol AVL – UAJS")
class ArbolAVLTest {

    private ArbolAVL avl;

    @BeforeEach
    void setUp() {
        avl = new ArbolAVL();
    }

    // ── Tests básicos DADOS (deben pasar desde el inicio) ─────────────

    @Test
    @DisplayName("Árbol recién creado está vacío")
    void testArbolVacio() {
        assertTrue(avl.esVacio());
        assertEquals(-1, avl.altura());
        assertEquals(0,  avl.tamanio());
    }

    @Test
    @DisplayName("Insertar un nodo: tamaño 1, altura 0")
    void testInsertarUno() {
        avl.insertar(10);
        assertEquals(1, avl.tamanio());
        assertEquals(0, avl.altura());
        assertTrue(avl.estaBalanceado());
    }

    @Test
    @DisplayName("Inserción en orden ASC provoca rotación izquierda y queda balanceado")
    void testRotacionIzquierdaSimple() {
        // 10 → 20 → 30: sin AVL sería una cadena, con AVL rota y queda 20 como raíz
        avl.insertar(10);
        avl.insertar(20);
        avl.insertar(30);
        assertTrue(avl.estaBalanceado(), "Debe estar balanceado tras insertar 10,20,30");
        assertEquals(1, avl.altura(), "Altura debe ser 1 (árbol perfecto de 3 nodos)");
    }

    @Test
    @DisplayName("Inserción en orden DESC provoca rotación derecha y queda balanceado")
    void testRotacionDerechaSimple() {
        avl.insertar(30);
        avl.insertar(20);
        avl.insertar(10);
        assertTrue(avl.estaBalanceado());
        assertEquals(1, avl.altura());
    }

    @Test
    @DisplayName("INORDEN siempre produce secuencia ordenada")
    void testInordenOrdenado() {
        int[] insertar = {5, 3, 7, 1, 4, 6, 8};
        for (int v : insertar) avl.insertar(v);

        List<Integer> inorden = avl.inorden();
        for (int i = 0; i < inorden.size() - 1; i++) {
            assertTrue(inorden.get(i) < inorden.get(i + 1),
                    "INORDEN debe estar ordenado: " + inorden);
        }
    }

    @Test
    @DisplayName("Búsqueda: encontrar elementos existentes")
    void testBuscarExistente() {
        for (int v : new int[]{10, 20, 5, 15, 25}) avl.insertar(v);
        assertTrue(avl.buscar(10));
        assertTrue(avl.buscar(5));
        assertTrue(avl.buscar(25));
    }

    @Test
    @DisplayName("Búsqueda: no encontrar elementos inexistentes")
    void testBuscarInexistente() {
        for (int v : new int[]{10, 20, 5}) avl.insertar(v);
        assertFalse(avl.buscar(99));
        assertFalse(avl.buscar(-1));
    }

    @Test
    @DisplayName("Árbol sigue balanceado con 15 inserciones aleatorias")
    void testBalanceoTras15Inserciones() {
        int[] vals = {50, 25, 75, 10, 30, 60, 80, 5, 15, 27, 35, 55, 65, 77, 90};
        for (int v : vals) {
            avl.insertar(v);
            assertTrue(avl.estaBalanceado(),
                    "Árbol debe estar balanceado tras insertar " + v);
        }
    }

    @Test
    @DisplayName("Doble rotación IZQ-DER: insertar 30, 10, 20")
    void testDobleRotacionIzquierdaDerecha() {
        avl.insertar(30);
        avl.insertar(10);
        avl.insertar(20); // Produce doble rotación Izq-Der, 20 sube a raíz
        assertTrue(avl.estaBalanceado());
        assertEquals(1, avl.altura());
    }

    @Test
    @DisplayName("Doble rotación DER-IZQ: insertar 10, 30, 20")
    void testDobleRotacionDerechaIzquierda() {
        avl.insertar(10);
        avl.insertar(30);
        avl.insertar(20); // Produce doble rotación Der-Izq
        assertTrue(avl.estaBalanceado());
        assertEquals(1, avl.altura());
    }

    // ── Tests de ELIMINACIÓN — DEBEN PASAR AL COMPLETAR EL TODO ──────

    @Test
    @DisplayName("Eliminar hoja: tamaño decrece y árbol sigue balanceado")
    void testEliminarHoja() {
        for (int v : new int[]{10, 5, 15}) avl.insertar(v);
        avl.eliminar(5); // hoja
        assertEquals(2,  avl.tamanio());
        assertFalse(avl.buscar(5));
        assertTrue(avl.estaBalanceado());
    }

    @Test
    @DisplayName("Eliminar nodo con un hijo: estructura correcta")
    void testEliminarNodoUnHijo() {
        for (int v : new int[]{20, 10, 30, 5}) avl.insertar(v);
        avl.eliminar(10); // tiene solo hijo izquierdo (5)
        assertFalse(avl.buscar(10));
        assertTrue(avl.buscar(5));
        assertTrue(avl.estaBalanceado());
    }

    @Test
    @DisplayName("Eliminar nodo con dos hijos: sucesor inorden reemplaza correctamente")
    void testEliminarNodoDobleHijo() {
        for (int v : new int[]{10, 5, 20, 15, 25}) avl.insertar(v);
        avl.eliminar(20); // tiene hijos 15 y 25
        assertFalse(avl.buscar(20));
        assertTrue(avl.buscar(15));
        assertTrue(avl.buscar(25));
        // INORDEN sigue ordenado
        List<Integer> io = avl.inorden();
        for (int i = 0; i < io.size() - 1; i++) {
            assertTrue(io.get(i) < io.get(i + 1));
        }
        assertTrue(avl.estaBalanceado());
    }

    @Test
    @DisplayName("Árbol sigue balanceado tras 5 eliminaciones seguidas")
    void testBalanceoTrasEliminaciones() {
        int[] insertar = {50, 25, 75, 10, 30, 60, 80};
        for (int v : insertar) avl.insertar(v);

        int[] eliminar = {10, 75, 25, 80, 60};
        for (int v : eliminar) {
            avl.eliminar(v);
            assertTrue(avl.estaBalanceado(),
                    "Árbol debe permanecer balanceado tras eliminar " + v);
        }
    }
}
