const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, LevelFormat, PageBreak
} = require("docx");
const fs = require("fs");

const AZUL        = "1565C0";
const AZUL_CLARO  = "DDEEFF";
const VERDE       = "1B5E20";
const VERDE_CLARO = "E8F5E9";
const GRIS_HDR    = "1E2D40";
const GRIS_CLARO  = "F4F6F8";
const NARANJA     = "E65100";
const NARANJA_C   = "FFF3E0";
const ROJO_C      = "FFEBEE";
const ROJO        = "B71C1C";
const BORDE       = "CCCCCC";

const border  = { style: BorderStyle.SINGLE, size: 1, color: BORDE };
const borders = { top: border, bottom: border, left: border, right: border };

// ── Helpers ─────────────────────────────────────────────────────
const spacer = (pts = 120) =>
  new Paragraph({ children: [], spacing: { before: pts, after: 0 } });

const hr = () =>
  new Paragraph({
    children: [new TextRun("")],
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: AZUL, space: 1 } },
    spacing: { before: 60, after: 60 },
  });

const colorBox = (titulo, lineas, fill, titleColor) =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({ children: [new TableCell({
      borders, width: { size: 9360, type: WidthType.DXA },
      shading: { fill, type: ShadingType.CLEAR },
      margins: { top: 120, bottom: 120, left: 180, right: 180 },
      children: [
        new Paragraph({ children: [new TextRun({ text: titulo, bold: true, color: titleColor, font: "Arial", size: 22 })], spacing: { after: 80 } }),
        ...lineas,
      ],
    })]})],
  });

const code = (lineas) =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({ children: [new TableCell({
      borders, width: { size: 9360, type: WidthType.DXA },
      shading: { fill: "1E2D40", type: ShadingType.CLEAR },
      margins: { top: 120, bottom: 120, left: 200, right: 200 },
      children: lineas.map(l => new Paragraph({
        children: [new TextRun({ text: l, font: "Consolas", size: 18, color: "A8D8A8" })],
        spacing: { before: 20, after: 20 },
      })),
    })]})],
  });

const bullet = (texto) =>
  new Paragraph({
    numbering: { reference: "bullets", level: 0 },
    children: [new TextRun({ text: texto, font: "Arial", size: 22 })],
    spacing: { before: 60, after: 40 },
  });

const numbered = (texto) =>
  new Paragraph({
    numbering: { reference: "pasos", level: 0 },
    children: [new TextRun({ text: texto, font: "Arial", size: 22 })],
    spacing: { before: 80, after: 60 },
  });

const todo = (texto) =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [9360],
    rows: [new TableRow({ children: [new TableCell({
      borders: { top: { style: BorderStyle.SINGLE, size: 3, color: NARANJA }, bottom: { style: BorderStyle.SINGLE, size: 3, color: NARANJA }, left: { style: BorderStyle.SINGLE, size: 12, color: NARANJA }, right: { style: BorderStyle.SINGLE, size: 1, color: BORDE } },
      width: { size: 9360, type: WidthType.DXA },
      shading: { fill: NARANJA_C, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 180, right: 180 },
      children: [new Paragraph({ children: [new TextRun({ text: "✏️  TODO: " + texto, font: "Arial", size: 21, color: NARANJA, bold: true })] })],
    })]})],
  });

// ── Tabla rotaciones ─────────────────────────────────────────────
const tablaRotaciones = () =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1800, 2000, 2200, 1760],
    rows: [
      new TableRow({ children: ["Caso","FE(nodo)","FE(hijo)","Rotación","Mnemotécnico"].map((h,ci) =>
        new TableCell({
          borders, width:{ size:[1600,1800,2000,2200,1760][ci], type:WidthType.DXA },
          shading: { fill: GRIS_HDR, type: ShadingType.CLEAR },
          margins: { top:80,bottom:80,left:120,right:120 },
          children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text:h, bold:true, color:"FFFFFF", font:"Arial", size:19 })] })],
        })
      )}),
      ...[
        ["IZQ–IZQ","< −1","≤ 0","Simple Derecha",  "Árbol cargado a la izquierda"],
        ["IZQ–DER","< −1","> 0","Doble: Izq→Der",  "Hijo derecho del izq. sube"],
        ["DER–DER","> +1","≥ 0","Simple Izquierda", "Árbol cargado a la derecha"],
        ["DER–IZQ","> +1","< 0","Doble: Der→Izq",  "Hijo izq. del der. sube"],
      ].map((row,ri) => new TableRow({ children: row.map((cell,ci)=>
        new TableCell({
          borders, width:{ size:[1600,1800,2000,2200,1760][ci], type:WidthType.DXA },
          shading: { fill: ri%2===0 ? GRIS_CLARO:"FFFFFF", type:ShadingType.CLEAR },
          margins: { top:80,bottom:80,left:120,right:120 },
          children: [new Paragraph({ alignment: ci<=2?AlignmentType.CENTER:AlignmentType.LEFT, children: [new TextRun({ text:cell, font:ci<=2?"Consolas":"Arial", size:19, bold:ci<=2, color:ci===1?ROJO:ci===2?VERDE:ci===3?AZUL:"333333" })] })],
        })
      )})),
    ],
  });

// ── Tabla métodos ────────────────────────────────────────────────
const tablaMetodos = () =>
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3200, 3600, 2560],
    rows: [
      new TableRow({ children: ["Método","Descripción","Complejidad"].map((h,ci)=>
        new TableCell({ borders, width:{size:[3200,3600,2560][ci],type:WidthType.DXA}, shading:{fill:GRIS_HDR,type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
          children:[new Paragraph({alignment:AlignmentType.CENTER, children:[new TextRun({text:h,bold:true,color:"FFFFFF",font:"Arial",size:20})]})]
        })
      )}),
      ...[
        ["insertar(dato)","Inserta y rebalancea automáticamente","O(log n)"],
        ["eliminar(dato)","Elimina y rebalancea (TODO estudiante)","O(log n)"],
        ["buscar(dato)","Búsqueda garantizada por balance AVL","O(log n)"],
        ["estaBalanceado()","Verifica la propiedad AVL en todo el árbol","O(n)"],
        ["factorEquilibrio(nodo)","FE = altura(der) − altura(izq)","O(1)"],
        ["altura()","Altura del árbol completo","O(1)"],
        ["inorden()","Secuencia ordenada","O(n)"],
        ["imprimirArbol()","Visualización con FE en consola","O(n)"],
      ].map((row,ri)=>new TableRow({ children: row.map((cell,ci)=>
        new TableCell({ borders, width:{size:[3200,3600,2560][ci],type:WidthType.DXA}, shading:{fill:ri%2===0?GRIS_CLARO:"FFFFFF",type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
          children:[new Paragraph({ children:[new TextRun({text:cell, font:ci===0?"Consolas":"Arial", size:19, color:ci===0?AZUL:ci===2?NARANJA:"333333", bold:ci===2})]})]
        })
      )})),
    ],
  });

// ════════════════════════════════════════════════════════════════
// DOCUMENTO
// ════════════════════════════════════════════════════════════════
const doc = new Document({
  numbering: {
    config: [
      { reference:"bullets", levels:[{ level:0, format:LevelFormat.BULLET, text:"•", alignment:AlignmentType.LEFT, style:{paragraph:{indent:{left:720,hanging:360}}}}]},
      { reference:"pasos",   levels:[{ level:0, format:LevelFormat.DECIMAL, text:"%1.", alignment:AlignmentType.LEFT, style:{paragraph:{indent:{left:720,hanging:360}}}}]},
    ],
  },
  styles: {
    default: { document: { run: { font:"Arial", size:22 } } },
    paragraphStyles: [
      { id:"Heading1", name:"Heading 1", basedOn:"Normal", next:"Normal", quickFormat:true,
        run:{size:36,bold:true,font:"Arial",color:GRIS_HDR}, paragraph:{spacing:{before:360,after:180},outlineLevel:0} },
      { id:"Heading2", name:"Heading 2", basedOn:"Normal", next:"Normal", quickFormat:true,
        run:{size:28,bold:true,font:"Arial",color:AZUL}, paragraph:{spacing:{before:280,after:120},outlineLevel:1} },
      { id:"Heading3", name:"Heading 3", basedOn:"Normal", next:"Normal", quickFormat:true,
        run:{size:24,bold:true,font:"Arial",color:VERDE}, paragraph:{spacing:{before:200,after:80},outlineLevel:2} },
    ],
  },
  sections: [{
    properties: { page: { size:{width:12240,height:15840}, margin:{top:1440,right:1440,bottom:1440,left:1440} } },
    headers: { default: new Header({ children: [
      new Paragraph({ children:[
        new TextRun({text:"Guía de Laboratorio – Árbol AVL | Balanceo Automático",font:"Arial",size:18,color:"888888"}),
        new TextRun({text:"    UAJS – Estructuras de Datos No Lineales",font:"Arial",size:18,color:"AAAAAA"}),
      ], border:{bottom:{style:BorderStyle.SINGLE,size:4,color:AZUL,space:1}}, spacing:{after:80} }),
    ]})},
    footers: { default: new Footer({ children: [
      new Paragraph({ children:[
        new TextRun({text:"Ing. Jaider Reyes Herazo  |  MSc. Gestión de la Innovación  |  UAJS  |  Página ",font:"Arial",size:16,color:"888888"}),
        new TextRun({children:[PageNumber.CURRENT],font:"Arial",size:16,color:"888888"}),
      ], border:{top:{style:BorderStyle.SINGLE,size:4,color:AZUL,space:1}}, alignment:AlignmentType.CENTER, spacing:{before:80} }),
    ]})},

    children: [

      // ── PORTADA ────────────────────────────────────────────────
      new Paragraph({ children:[new TextRun({text:"GUÍA DE LABORATORIO",font:"Arial",size:48,bold:true,color:GRIS_HDR})], alignment:AlignmentType.CENTER, spacing:{before:600,after:200} }),
      new Paragraph({ children:[new TextRun({text:"Árboles AVL – Balanceo Automático",font:"Arial",size:34,bold:true,color:AZUL})], alignment:AlignmentType.CENTER, spacing:{after:120} }),
      new Paragraph({ children:[new TextRun({text:"Adelson-Velskii & Landis | Rotaciones | Proyecto Java + Maven",font:"Arial",size:22,italic:true,color:"555555"})], alignment:AlignmentType.CENTER, spacing:{after:400} }),
      hr(),
      spacer(200),
      new Table({
        width:{size:9360,type:WidthType.DXA}, columnWidths:[4680,4680],
        rows:[
          new TableRow({ children:[
            new TableCell({ borders, width:{size:4680,type:WidthType.DXA}, shading:{fill:GRIS_CLARO,type:ShadingType.CLEAR}, margins:{top:120,bottom:120,left:180,right:180},
              children:[
                new Paragraph({children:[new TextRun({text:"Asignatura",bold:true,font:"Arial",size:20,color:AZUL})],spacing:{after:60}}),
                new Paragraph({children:[new TextRun({text:"Estructuras de Datos No Lineales",font:"Arial",size:20})]}),
              ],
            }),
            new TableCell({ borders, width:{size:4680,type:WidthType.DXA}, shading:{fill:GRIS_CLARO,type:ShadingType.CLEAR}, margins:{top:120,bottom:120,left:180,right:180},
              children:[
                new Paragraph({children:[new TextRun({text:"Prerrequisito",bold:true,font:"Arial",size:20,color:AZUL})],spacing:{after:60}}),
                new Paragraph({children:[new TextRun({text:"Guía de ABB + Indexador de Palabras",font:"Arial",size:20})]}),
              ],
            }),
          ]}),
          new TableRow({ children:[
            new TableCell({ borders, width:{size:4680,type:WidthType.DXA}, shading:{fill:GRIS_CLARO,type:ShadingType.CLEAR}, margins:{top:120,bottom:120,left:180,right:180},
              children:[
                new Paragraph({children:[new TextRun({text:"Docente",bold:true,font:"Arial",size:20,color:AZUL})],spacing:{after:60}}),
                new Paragraph({children:[new TextRun({text:"Ing. Jaider Reyes Herazo",font:"Arial",size:20})]}),
              ],
            }),
            new TableCell({ borders, width:{size:4680,type:WidthType.DXA}, shading:{fill:GRIS_CLARO,type:ShadingType.CLEAR}, margins:{top:120,bottom:120,left:180,right:180},
              children:[
                new Paragraph({children:[new TextRun({text:"Tecnología",bold:true,font:"Arial",size:20,color:AZUL})],spacing:{after:60}}),
                new Paragraph({children:[new TextRun({text:"Java 17 + Maven 3.x + JUnit 5",font:"Arial",size:20})]}),
              ],
            }),
          ]}),
        ],
      }),
      spacer(400),

      // ── 1. INTRO ───────────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("1. Introducción")] }),
      hr(), spacer(80),
      new Paragraph({ children:[new TextRun({text:"El Árbol AVL (Adelson-Velskii & Landis, 1962) resuelve el problema fundamental del ABB: en el peor caso, un BST simple puede degenerar en una lista enlazada con O(n) de búsqueda. El AVL introduce el concepto de balance automático: después de cada inserción o eliminación, el árbol se reestructura mediante rotaciones para garantizar que su altura se mantenga en O(log n).", font:"Arial", size:22})], alignment:AlignmentType.JUSTIFIED, spacing:{after:160} }),
      new Paragraph({ children:[new TextRun({text:"Esta guía te lleva desde la teoría hasta el código Java: primero comprendes el Factor de Equilibrio y las 4 rotaciones, luego completas la implementación del método de eliminación con los 3 casos vistos en clase, y finalmente ejecutas los tests JUnit 5 hasta que todos pasen en verde.", font:"Arial", size:22})], alignment:AlignmentType.JUSTIFIED, spacing:{after:200} }),

      colorBox("🧠 ¿Por qué AVL y no solo BST?", [
        new Paragraph({children:[new TextRun({text:"BST con inserción ordenada 1,2,3,...,n → altura n−1 → búsqueda O(n). Es exactamente como buscar en una lista.",font:"Arial",size:21})], spacing:{after:60}}),
        new Paragraph({children:[new TextRun({text:"AVL con la misma inserción → altura ≈ 1.44·log₂n → búsqueda O(log n) GARANTIZADA siempre.",font:"Arial",size:21})], spacing:{after:0}}),
      ], AZUL_CLARO, AZUL),
      spacer(200),

      // ── 2. OBJETIVOS ───────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("2. Objetivos de Aprendizaje")] }),
      hr(), spacer(80),
      bullet("Comprender el Factor de Equilibrio (FE) y su papel en el AVL."),
      bullet("Identificar y aplicar los 4 tipos de rotaciones (Simple Der, Simple Izq, Doble Izq-Der, Doble Der-Izq)."),
      bullet("Completar la implementación de la eliminación AVL con los 3 casos (hoja, un hijo, dos hijos)."),
      bullet("Verificar el comportamiento del árbol con tests JUnit 5 automatizados."),
      bullet("Comparar empíricamente la altura de un AVL vs un BST degenerado."),
      spacer(200),

      // ── 3. MARCO CONCEPTUAL ────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("3. Marco Conceptual")] }),
      hr(), spacer(80),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("3.1 Factor de Equilibrio (FE)")] }),
      new Paragraph({ children:[new TextRun({text:"Para cada nodo N del árbol, el Factor de Equilibrio se define como:",font:"Arial",size:22})], spacing:{after:100} }),
      code(["FE(N) = altura(subárbol derecho de N)  −  altura(subárbol izquierdo de N)"]),
      spacer(80),
      new Paragraph({ children:[new TextRun({text:"La propiedad AVL exige que FE ∈ {−1, 0, +1} para TODOS los nodos. Si después de una inserción o eliminación algún nodo tiene |FE| > 1, el árbol está desbalanceado y se aplica la rotación correspondiente.",font:"Arial",size:22})], alignment:AlignmentType.JUSTIFIED, spacing:{after:200} }),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("3.2 Las 4 Rotaciones")] }),
      spacer(60),
      tablaRotaciones(),
      spacer(120),

      new Paragraph({ heading:HeadingLevel.HEADING_3, children:[new TextRun("3.2.1 Rotación Simple Derecha (caso IZQ–IZQ)")] }),
      code([
        "     y  (FE=-2)           x",
        "    / \\                  / \\",
        "   x   C    ──────►     A   y",
        "  / \\                      / \\",
        " A   B                    B   C",
        "",
        "  Trigger: insertar en el subárbol A (izquierda del izquierdo)",
        "  Acción:  rotarDerecha(y)  →  x sube, y baja a la derecha de x",
      ]),
      spacer(120),

      new Paragraph({ heading:HeadingLevel.HEADING_3, children:[new TextRun("3.2.2 Doble Rotación Izquierda-Derecha (caso IZQ–DER)")] }),
      code([
        "     z  (FE=-2)           z                y",
        "    / \\                  / \\              / \\",
        "   x   D   paso 1:      y   D  paso 2:  x   z",
        "  / \\           ──►    / \\        ──►  / \\ / \\",
        " A   y                x   C            A B  C  D",
        "    / \\              / \\",
        "   B   C            A   B",
        "",
        "  Paso 1: rotarIzquierda(x)   Paso 2: rotarDerecha(z)",
      ]),
      spacer(160),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("3.3 Eliminación en AVL")] }),
      new Paragraph({ children:[new TextRun({text:"La eliminación AVL combina los 3 casos del BST (vistos en clase) con el rebalanceo automático al retornar de la recursión:",font:"Arial",size:22})], spacing:{after:120} }),

      new Table({
        width:{size:9360,type:WidthType.DXA}, columnWidths:[800,2800,5760],
        rows:[
          new TableRow({children:["Caso","Situación","Procedimiento"].map((h,ci)=>
            new TableCell({ borders, width:{size:[800,2800,5760][ci],type:WidthType.DXA}, shading:{fill:GRIS_HDR,type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
              children:[new Paragraph({alignment:AlignmentType.CENTER, children:[new TextRun({text:h,bold:true,color:"FFFFFF",font:"Arial",size:20})]})]
            })
          )}),
          ...[
            ["1","Nodo hoja (sin hijos)","Retornar null. El padre pierde la referencia."],
            ["2","Un solo hijo","Retornar el hijo existente. El padre apunta directo al nieto."],
            ["3","Dos hijos","Buscar sucesor inorden (mínimo del subárbol derecho). Copiar su valor al nodo actual. Eliminar el sucesor del subárbol derecho."],
          ].map((row,ri)=>new TableRow({children:row.map((cell,ci)=>
            new TableCell({ borders, width:{size:[800,2800,5760][ci],type:WidthType.DXA}, shading:{fill:ri%2===0?GRIS_CLARO:"FFFFFF",type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
              children:[new Paragraph({alignment:ci===0?AlignmentType.CENTER:AlignmentType.LEFT, children:[new TextRun({text:cell,font:"Arial",size:20,bold:ci===0,color:ci===0?AZUL:"333333"})]})]
            })
          )}))
        ],
      }),
      spacer(80),
      colorBox("⚠️ Diferencia clave vs BST simple", [
        new Paragraph({children:[new TextRun({text:"En el AVL, después de aplicar cualquiera de los 3 casos, se llama a rebalancear() en el camino de vuelta de la recursión. Esto garantiza que el árbol recupere su propiedad AVL automáticamente.",font:"Arial",size:21})]}),
      ], NARANJA_C, NARANJA),
      spacer(200),

      // ── 4. ESTRUCTURA DEL PROYECTO ─────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("4. Estructura del Proyecto Maven")] }),
      hr(), spacer(80),
      code([
        "arboles-avl/",
        "├── pom.xml",
        "└── src/",
        "    ├── main/java/edu/uajas/estructuras/avl/",
        "    │   ├── NodoAVL.java          ← Nodo con campo 'altura'",
        "    │   ├── ArbolAVL.java         ← ★ CLASE PRINCIPAL (con TODO)",
        "    │   └── Main.java             ← Demo + taller interactivo",
        "    └── test/java/edu/uajas/estructuras/avl/",
        "        └── ArbolAVLTest.java     ← Tests JUnit 5 (algunos @Disabled)",
      ]),
      spacer(120),
      colorBox("🎯 Flujo de trabajo del laboratorio", [
        new Paragraph({children:[new TextRun({text:"1. Ejecuta mvn test → verás 9 tests en verde y 4 con @Disabled.",font:"Arial",size:21})], spacing:{after:60}}),
        new Paragraph({children:[new TextRun({text:"2. Lee los TODO en ArbolAVL.java. Implementa la eliminación (Casos 2 y 3).",font:"Arial",size:21})], spacing:{after:60}}),
        new Paragraph({children:[new TextRun({text:"3. Quita el @Disabled de los tests uno a uno. Ejecuta mvn test y corrige.",font:"Arial",size:21})], spacing:{after:60}}),
        new Paragraph({children:[new TextRun({text:"4. Objetivo final: todos los tests en VERDE. ✅",font:"Arial",size:21})], spacing:{after:0}}),
      ], VERDE_CLARO, VERDE),
      spacer(200),

      // ── 5. CÓDIGO ──────────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("5. Código Fuente: Partes Clave")] }),
      hr(), spacer(80),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("5.1 Método rebalancear() — ya implementado")] }),
      new Paragraph({ children:[new TextRun({text:"Este método es el corazón del AVL. Recibe un nodo, actualiza su altura, calcula el FE y aplica la rotación correcta:",font:"Arial",size:22})], spacing:{after:120} }),
      code([
        "private NodoAVL rebalancear(NodoAVL nodo) {",
        "    actualizarAltura(nodo);",
        "    int fe = factorEquilibrio(nodo);",
        "",
        "    if (fe < -1 && factorEquilibrio(nodo.izquierdo) <= 0)",
        "        return rotarDerecha(nodo);              // CASO IZQ-IZQ",
        "",
        "    if (fe < -1 && factorEquilibrio(nodo.izquierdo) > 0) {",
        "        nodo.izquierdo = rotarIzquierda(nodo.izquierdo);",
        "        return rotarDerecha(nodo);              // CASO IZQ-DER",
        "    }",
        "",
        "    if (fe > 1 && factorEquilibrio(nodo.derecho) >= 0)",
        "        return rotarIzquierda(nodo);            // CASO DER-DER",
        "",
        "    if (fe > 1 && factorEquilibrio(nodo.derecho) < 0) {",
        "        nodo.derecho = rotarDerecha(nodo.derecho);",
        "        return rotarIzquierda(nodo);            // CASO DER-IZQ",
        "    }",
        "    return nodo; // ya estaba balanceado",
        "}",
      ]),
      spacer(160),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("5.2 Método eliminarRec() — TU TAREA")] }),
      new Paragraph({ children:[new TextRun({text:"El esqueleto del método está en ArbolAVL.java. Tienes que completar los Casos 2 y 3:",font:"Arial",size:22})], spacing:{after:120} }),
      code([
        "private NodoAVL eliminarRec(NodoAVL nodo, int dato) {",
        "    if (nodo == null) return null;",
        "",
        "    if      (dato < nodo.dato) nodo.izquierdo = eliminarRec(nodo.izquierdo, dato);",
        "    else if (dato > nodo.dato) nodo.derecho   = eliminarRec(nodo.derecho,   dato);",
        "    else {",
        "        // CASO 1: nodo hoja — YA IMPLEMENTADO",
        "        if (nodo.izquierdo == null && nodo.derecho == null) return null;",
        "",
        "        // CASO 2: un solo hijo — TODO ESTUDIANTE",
        "        // if (nodo.izquierdo == null) return ???;",
        "        // if (nodo.derecho   == null) return ???;",
        "",
        "        // CASO 3: dos hijos — TODO ESTUDIANTE",
        "        // NodoAVL sucesor = minimoNodo(???);",
        "        // nodo.dato       = sucesor.dato;",
        "        // nodo.derecho    = eliminarRec(???, ???);",
        "    }",
        "    return rebalancear(nodo);  // ← siempre al final",
        "}",
      ]),
      spacer(120),
      todo("Completa el CASO 2: si izquierdo es null, retorna derecho; si derecho es null, retorna izquierdo."),
      spacer(80),
      todo("Completa el CASO 3: usa minimoNodo(nodo.derecho) para encontrar el sucesor, copia su dato, luego elimínalo del subárbol derecho."),
      spacer(200),

      // ── 6. MÉTODOS TABLA ───────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("6. API de la Clase ArbolAVL")] }),
      hr(), spacer(80),
      tablaMetodos(),
      spacer(200),

      // ── 7. ACTIVIDADES ─────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("7. Actividades del Laboratorio")] }),
      hr(), spacer(80),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("7.1 Actividad 1 — Prueba de Escritorio (20 min)")] }),
      new Paragraph({ children:[new TextRun({text:"Inserta la secuencia 10, 20, 30, 40, 50, 25 en un árbol AVL a mano. Dibuja el árbol después de CADA inserción y marca las rotaciones que se producen.",font:"Arial",size:22})], spacing:{after:120} }),
      numbered("Inserta 10 → árbol de 1 nodo, FE=0."),
      numbered("Inserta 20 → FE(10)=+1. Balanceado."),
      numbered("Inserta 30 → FE(10)=+2. ¿Qué rotación se aplica? Dibuja el árbol resultante."),
      numbered("Inserta 40 → FE(nueva raíz)=+1. Balanceado."),
      numbered("Inserta 50 → ¿qué nodo queda desbalanceado? ¿Qué rotación?"),
      numbered("Inserta 25 → FE(30)=−2 y FE(20)=+1. ¿Qué tipo de rotación DOBLE se aplica?"),
      spacer(80),
      colorBox("🔎 Verifica con el código", [
        new Paragraph({children:[new TextRun({text:"Después de hacer la prueba de escritorio, ejecuta mvn exec:java → Opción 1 (Demo automática) con los mismos valores y compara.",font:"Arial",size:21})]}),
      ], AZUL_CLARO, AZUL),
      spacer(160),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("7.2 Actividad 2 — Implementar Eliminación (30 min)")] }),
      new Paragraph({ children:[new TextRun({text:"Esta es la actividad central del laboratorio. Abre el archivo ArbolAVL.java en tu IDE y busca el método eliminarRec(). Verás los bloques marcados con TODO.",font:"Arial",size:22})], spacing:{after:120} }),
      numbered("Lee los comentarios del CASO 2. Implementa el retorno del hijo existente cuando el nodo tiene solo un hijo."),
      numbered("Lee los comentarios del CASO 3. Implementa la lógica del sucesor inorden usando el método minimoNodo() ya disponible."),
      numbered("Guarda el archivo. Ejecuta: mvn test"),
      numbered("Quita el @Disabled del test testEliminarHoja(). Ejecuta mvn test. ¿Pasa?"),
      numbered("Quita el @Disabled de los demás tests de eliminación uno a uno. Asegúrate de que todos pasen."),
      numbered("Meta final: ejecuta mvn test → 13/13 tests en verde ✅"),
      spacer(160),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("7.3 Actividad 3 — Comparativa de Alturas (20 min)")] }),
      new Paragraph({ children:[new TextRun({text:"Ejecuta la opción 3 del menú (Comparativa AVL vs BST) y luego responde en tu cuaderno:",font:"Arial",size:22})], spacing:{after:120} }),
      numbered("Con 10 nodos insertados en orden ascendente: ¿cuál es la altura del BST? ¿Y del AVL?"),
      numbered("Calcula manualmente la altura teórica del AVL: ⌈1.44 × log₂(11)⌉. ¿Coincide con el resultado del programa?"),
      numbered("¿Cuántas comparaciones necesita el BST degenerado para encontrar el valor 10? ¿Y el AVL?"),
      numbered("¿Por qué se dice que el peor caso del BST es equivalente a una búsqueda lineal?"),
      spacer(160),

      new Paragraph({ heading:HeadingLevel.HEADING_2, children:[new TextRun("7.4 Actividad 4 — Extensiones Avanzadas (opcional, +bonificación)")] }),
      new Paragraph({ children:[new TextRun({text:"Para los estudiantes que quieran ir más allá, el archivo ArbolAVL.java incluye 3 TODO avanzados:",font:"Arial",size:22})], spacing:{after:120} }),
      bullet("TODO Avanzado 1: Contador de rotaciones — ¿cuántas rotaciones produjo una secuencia de N inserciones?"),
      bullet("TODO Avanzado 2: buscarRango(min, max) — retorna todos los nodos entre dos valores usando poda del árbol."),
      bullet("TODO Avanzado 3: Comparación de altura teórica vs real con fórmula O(1.44·log₂n)."),
      spacer(200),

      // ── 8. RÚBRICA ─────────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("8. Rúbrica de Evaluación")] }),
      hr(), spacer(80),
      new Table({
        width:{size:9360,type:WidthType.DXA}, columnWidths:[3600,3500,2260],
        rows:[
          new TableRow({children:["Criterio","Indicador de logro","%"].map((h,ci)=>
            new TableCell({ borders, width:{size:[3600,3500,2260][ci],type:WidthType.DXA}, shading:{fill:GRIS_HDR,type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
              children:[new Paragraph({alignment:AlignmentType.CENTER, children:[new TextRun({text:h,bold:true,color:"FFFFFF",font:"Arial",size:20})]})]
            })
          )}),
          ...[
            ["Prueba de escritorio (Act. 1)","Rotaciones identificadas correctamente","20%"],
            ["Tests en verde (Act. 2)","13/13 tests pasan con mvn test","35%"],
            ["Comparativa de alturas (Act. 3)","Respuestas justificadas en cuaderno","20%"],
            ["Calidad del código","Comentarios, nombres, sin código muerto","15%"],
            ["Extensiones avanzadas (Act. 4)","Al menos 1 TODO avanzado implementado","10%"],
          ].map((row,ri)=>new TableRow({children:row.map((cell,ci)=>
            new TableCell({ borders, width:{size:[3600,3500,2260][ci],type:WidthType.DXA}, shading:{fill:ri%2===0?GRIS_CLARO:"FFFFFF",type:ShadingType.CLEAR}, margins:{top:80,bottom:80,left:120,right:120},
              children:[new Paragraph({alignment:ci===2?AlignmentType.CENTER:AlignmentType.LEFT, children:[new TextRun({text:cell,font:"Arial",size:20,bold:ci===2,color:ci===2?AZUL:"333333"})]})]
            })
          )}))
        ],
      }),
      spacer(200),

      // ── 9. RECURSOS ────────────────────────────────────────────
      new Paragraph({ heading:HeadingLevel.HEADING_1, children:[new TextRun("9. Recursos y Referencias")] }),
      hr(), spacer(80),
      bullet("Adelson-Velskii, G. M. & Landis, E. M. (1962). An algorithm for the organization of information."),
      bullet("Visualizador interactivo AVL: https://www.cs.usfca.edu/~galles/visualization/AVLtree.html"),
      bullet("Video tutorial (referenciado en el PPTX): https://www.youtube.com/watch?v=lQvCujvheAA"),
      bullet("JUnit 5 User Guide: https://junit.org/junit5/docs/current/user-guide/"),
      bullet("OSPF y AVL en enrutamiento: RFC 2328 – OSPF Version 2."),
      spacer(200),

      hr(),
      new Paragraph({ children:[new TextRun({text:"Ing. Jaider Reyes Herazo  ·  MSc. Gestión de la Innovación  ·  PhD(c) Estudios Organizacionales",font:"Arial",size:18,italic:true,color:"888888"})], alignment:AlignmentType.CENTER, spacing:{before:120,after:40} }),
      new Paragraph({ children:[new TextRun({text:"Corporación Universitaria Antonio José de Sucre (UAJS)  ·  Sincelejo, Colombia",font:"Arial",size:18,color:"888888"})], alignment:AlignmentType.CENTER }),
    ],
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("/mnt/user-data/outputs/Guia_Laboratorio_AVL_UAJS.docx", buffer);
  console.log("✅ Guía Word AVL generada");
}).catch(e => { console.error("❌", e); process.exit(1); });
